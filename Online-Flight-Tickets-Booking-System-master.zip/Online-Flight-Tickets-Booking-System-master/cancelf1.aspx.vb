
Partial Class cancelf1
    Inherits System.Web.UI.Page

End Class
