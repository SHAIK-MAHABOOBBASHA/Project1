
Partial Class exist1
    Inherits System.Web.UI.Page

End Class
