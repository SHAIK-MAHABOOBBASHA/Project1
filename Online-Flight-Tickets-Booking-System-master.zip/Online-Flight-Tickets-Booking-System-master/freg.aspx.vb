
Partial Class freg
    Inherits System.Web.UI.Page

End Class
