
Partial Class texist1
    Inherits System.Web.UI.Page

End Class
