Imports Microsoft.VisualBasic

Public Module module1
    Public cn As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public rs1 As New ADODB.Recordset
    Public rs2 As New ADODB.Recordset
    Public sql
End Module
