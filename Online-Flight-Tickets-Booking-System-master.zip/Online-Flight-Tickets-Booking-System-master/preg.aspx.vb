
Partial Class preg
    Inherits System.Web.UI.Page

End Class
