
Partial Class tckexist
    Inherits System.Web.UI.Page

End Class
