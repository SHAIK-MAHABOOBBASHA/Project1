
Partial Class treg
    Inherits System.Web.UI.Page

End Class
