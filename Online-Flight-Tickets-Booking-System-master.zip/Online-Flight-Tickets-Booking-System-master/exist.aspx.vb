
Partial Class exist
    Inherits System.Web.UI.Page

End Class
