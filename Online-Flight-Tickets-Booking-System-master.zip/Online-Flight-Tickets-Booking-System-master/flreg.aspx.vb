
Partial Class flreg
    Inherits System.Web.UI.Page

End Class
