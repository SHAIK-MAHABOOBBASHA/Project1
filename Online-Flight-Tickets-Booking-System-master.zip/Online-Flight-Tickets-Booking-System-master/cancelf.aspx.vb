
Partial Class cancelf
    Inherits System.Web.UI.Page

End Class
