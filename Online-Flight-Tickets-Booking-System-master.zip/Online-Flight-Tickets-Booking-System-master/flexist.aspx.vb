
Partial Class flexist
    Inherits System.Web.UI.Page

End Class
