
Partial Class reg
    Inherits System.Web.UI.Page

End Class
